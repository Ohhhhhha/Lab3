package lab3_3;

public class CashRegisterTester {
    public static void main(String[] args)
    {
        CashRegister totalCash = new CashRegister(100);
        totalCash.recordTaxablePurchase(20);
        totalCash.recordPurchase(50);
        totalCash.recordPurchase(10);
        totalCash.getTotalTax();
        System.out.println("Your change is "+String.format("%.1f",totalCash.giveChange()));
    }
  
}
