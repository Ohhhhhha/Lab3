package lab3_1;

public class InsectPopulationTester {
    public static void main(String[]args){
       InsectPopulation insectnumber = new InsectPopulation(10);
       insectnumber.breed();
       insectnumber.spray();
       System.out.println("Number of insects: "+insectnumber.getNumInsect());
       
       insectnumber.breed();
       insectnumber.spray();
       System.out.println("Number of insects: "+insectnumber.getNumInsect());
       
       insectnumber.breed();
       insectnumber.spray();
       System.out.println("Number of insects: "+insectnumber.getNumInsect());
    }    
}
