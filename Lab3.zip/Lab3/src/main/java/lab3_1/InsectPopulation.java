
package lab3_1;

public class InsectPopulation {
    public double insectnumber;
    public InsectPopulation(double pop) {
        insectnumber = pop;
    }     
    public void breed(){
        insectnumber = insectnumber *2;    
    }
    public void spray(){
        insectnumber = insectnumber*0.9 ;
    }
    public double getNumInsect(){
        return insectnumber ;
    }
       
}
